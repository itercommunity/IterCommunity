<?php
/*
Plugin Module: HTML
Description: This plugin creates subsites for HTML	
Author: Shawn DeWolfe - mikedewolfe@gmail.com
Version: 0.1
Author URI: http://etcl.uvic.ca/TBA
*/

/* share for the most part */

/* do the form management */

if ($good != $replaced) {
	sboxr_make_html();
}
else {
	// error
	
}

/* the actual functions */

?>