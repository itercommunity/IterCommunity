<?php
/*
Plugin Module: Archive
Description: This plugin creates subsites for Archived projects-- those pushed into OwnCloud	
Author: Shawn DeWolfe - mikedewolfe@gmail.com
Version: 0.1
Author URI: http://etcl.uvic.ca/TBA
*/

/* share for the most part */

/* do the form management */

if ($good != $replaced) {
	sboxr_make_archive();
}
else {
	// error
	
}

/* the actual functions */



?>