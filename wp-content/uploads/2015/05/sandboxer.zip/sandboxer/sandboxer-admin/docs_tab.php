<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>
<div class="wrap">
	<h2><?php _e('Sandboxer Documentation'); ?></h2>
	<div class="postbox">
	<!-- list the topics and link to the home site -->
	XX
	</div>
</div>