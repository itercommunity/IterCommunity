First off — change the name of “WP-Sandbox-Generator” to something that we will deploy with.
Second — follow the howto_DNC.txt 