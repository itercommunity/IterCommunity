<p class="personalblock"><strong>CloudPress</strong><br/>
<?=sizeof($_['blogs'])?> <?php echo $l->t('site(s)') ?>
</p>
