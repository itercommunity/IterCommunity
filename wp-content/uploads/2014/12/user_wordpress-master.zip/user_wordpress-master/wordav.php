<?php

/**
 * ownCloud
 *
 * @author Frank Karlitschek
 * @author Jakob Sack
 * @copyright 2012 Frank Karlitschek frank@owncloud.org
 * @copyright 2011 Jakob Sack kde@jakobsack.de
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU AFFERO GENERAL PUBLIC LICENSE
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU AFFERO GENERAL PUBLIC LICENSE for more details.
 *
 * You should have received a copy of the GNU Affero General Public
 * License along with this library.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
// only need filesystem apps
//echo json_encode('WP is here !');
//
//echo $baseuri;
$RUNTIME_APPTYPES=array('filesystem','authentication','share');//
OC_App::loadApps($RUNTIME_APPTYPES);

require_once('apps/user_wordpress/lib/autoauth.php');

if(isset($_REQUEST['share_link'])){
	if (OC_App::isEnabled('files_sharing')) {
		$file_path = urldecode(substr(implode('/',array_slice($vars,5)),0,-11));
		$file_infos= OC_Files::getFileInfo($file_path);
		$token='';
		
		// is the file allready shared ?
		$shares = OCP\Share::getItemShared('file', $file_infos['id'], OCP\Share::FORMAT_NONE, null, true);
		foreach($shares as $share){
			if($share['path']==$file_infos['path']){
				$token=$share['token'];	
			}
		}
		// if not, let's share the file
		if(empty($token)) $token = OCP\Share::shareItem('file', $file_infos['id'], 3, NULL, 1);
		
		// return token
		echo trim($token);
	}
	exit();	
}

if(isset($_REQUEST['back'])){
	header('location:'.$_REQUEST['back']);
}

//$baseuri = OC::$WEBROOT. '/apps/user_wordpress/wordav.php';

//$baseuri=implode('/',array_slice($vars,5));
//echo '<br>'.$baseuri;

// Backends
//$lockBackend = new OC_Connector_Sabre_Locks();

// Create ownCloud Dir
$publicDir = new OC_Connector_Sabre_Directory('');

// Fire up server
$server = new Sabre_DAV_Server($publicDir);
$server->setBaseUri($baseuri);

// Load plugins
//$server->addPlugin(new Sabre_DAV_Locks_Plugin($lockBackend));
$server->addPlugin(new Sabre_DAV_Browser_Plugin(true)); // Show something in the Browser, but no upload

// And off we go!
$server->exec();
